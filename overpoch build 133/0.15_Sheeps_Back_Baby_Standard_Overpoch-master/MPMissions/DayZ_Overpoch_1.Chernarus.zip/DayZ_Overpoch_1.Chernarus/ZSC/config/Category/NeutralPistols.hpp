class Category_606 {
class M9SD {type = "trade_weapons";buy[] ={17500,"Coins"};sell[] ={7500,"Coins"};};
class glock17_EP1 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class Colt1911 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class M9 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class MakarovSD {type = "trade_weapons";buy[] ={5000,"Coins"};sell[] ={1000,"Coins"};};
class revolver_gold_EP1 {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={7500,"Coins"};};
class Makarov {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={10000,"Coins"};};
class revolver_EP1 {type = "trade_weapons";buy[] ={18500,"Coins"};sell[] ={7500,"Coins"};};
};
class Category_674 {
class M9SD {type = "trade_weapons";buy[] ={17500,"Coins"};sell[] ={7500,"Coins"};};
class glock17_EP1 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class Colt1911 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class M9 {type = "trade_weapons";buy[] ={15000,"Coins"};sell[] ={5000,"Coins"};};
class MakarovSD {type = "trade_weapons";buy[] ={5000,"Coins"};sell[] ={1000,"Coins"};};
class revolver_gold_EP1 {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={7500,"Coins"};};
class Makarov {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={10000,"Coins"};};
class revolver_EP1 {type = "trade_weapons";buy[] ={18500,"Coins"};sell[] ={7500,"Coins"};};
};
