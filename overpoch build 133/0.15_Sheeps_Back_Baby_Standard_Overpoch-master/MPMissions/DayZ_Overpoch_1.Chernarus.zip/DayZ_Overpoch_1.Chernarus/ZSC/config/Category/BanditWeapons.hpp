class Category_627 {
	class G36_C_SD_camo {
		type = "trade_weapons";
		buy[] ={5000,"Coins"};
		sell[] ={1250,"Coins"};
	};
	class M4A1_AIM_SD_camo {
		type = "trade_weapons";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class SCAR_H_LNG_Sniper_SD {
		type = "trade_weapons";
		buy[] ={70000,"Coins"};
		sell[] ={17500,"Coins"};
	};
	class BAF_LRR_scoped {
		type = "trade_weapons";
		buy[] ={90000,"Coins"};
		sell[] ={30000,"Coins"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] ={55000,"Coins"};
		sell[] ={7500,"Coins"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] ={55000,"Coins"};
		sell[] ={7500,"Coins"};
	};
};
