class Category_658 {
	class HMMWV_M1035_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class HMMWV_Ambulance {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class HMMWV_Ambulance_CZ_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class HMMWV_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class GAZ_Vodnik_MedEvac {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class HMMWV_DZ {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class LandRover_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class LandRover_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};
class Category_598 {
	class HMMWV_M1035_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class HMMWV_Ambulance {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class HMMWV_Ambulance_CZ_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class HMMWV_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class GAZ_Vodnik_MedEvac {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class HMMWV_DZ {
		type = "trade_any_vehicle";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class LandRover_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class LandRover_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};
