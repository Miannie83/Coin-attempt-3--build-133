class Category_1014 {
class CYBP_Camel_us { type = "trade_any_vehicle"; buy[] = {200000,"Coins"}; sell[] = {100000,"Coins"};};
class CYBP_Camel_civ { type = "trade_any_vehicle"; buy[] = {200000,"Coins"}; sell[] = {100000,"Coins"};};
};