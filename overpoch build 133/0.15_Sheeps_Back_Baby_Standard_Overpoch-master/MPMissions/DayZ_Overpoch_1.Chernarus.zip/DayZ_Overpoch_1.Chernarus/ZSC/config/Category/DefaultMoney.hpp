class Category_700 {
	class ItemBriefcase100oz {
		type = "trade_items";
		buy[] ={100000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class ItemGoldBar {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemGoldBar10oz {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class ItemSilverBar {
		type = "trade_items";
		buy[] ={10,"Coins"};
		sell[] ={10,"Coins"};
	};
	class ItemSilverBar10oz {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={100,"Coins"};
	};
	class ItemCopperBar10oz {
		type = "trade_items";
		buy[] ={1,"Coins"};
		sell[] ={1,"Coins"};
	};
	class ItemTinBar {
		type = "trade_items";
		buy[] ={2,"Coins"};
		sell[] ={2,"Coins"};
	};
    class ItemAluminumBar {
	    type = "trade_items";                 
		buy[] ={2,"Coins"};
		sell[] ={2,"Coins"};
       };
	
	class ItemObsidian{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={100000,"Coins"};
       };
 
    class PartOre {
	    type = "trade_items";                 
		buy[] ={20,"Coins"};
		sell[] ={20,"Coins"};
       };
	   
	class PartOreSilver {
	    type = "trade_items";                 
		buy[] ={30,"Coins"};
		sell[] ={30,"Coins"};
       };
	   
	class PartOreGold {
	    type = "trade_items";                 
		buy[] ={1000,"Coins"};
		sell[] ={1000,"Coins"};
       };
};