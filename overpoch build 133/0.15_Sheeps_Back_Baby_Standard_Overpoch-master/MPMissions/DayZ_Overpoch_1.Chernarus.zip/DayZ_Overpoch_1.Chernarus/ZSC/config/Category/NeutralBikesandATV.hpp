class Category_650 {
	class MMT_Civ {
		type = "trade_any_bicycle";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class Old_bike_TK_INS_EP1 {
		type = "trade_any_bicycle";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class TT650_Civ {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class TT650_Ins {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class TT650_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ATV_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M1030_US_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Old_moto_TK_Civ_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class tractor {
		type = "trade_any_vehicle";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
};
class Category_587 {
	class MMT_Civ {
		type = "trade_any_bicycle";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class Old_bike_TK_INS_EP1 {
		type = "trade_any_bicycle";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class TT650_Civ {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class TT650_Ins {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class TT650_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ATV_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class M1030_US_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class Old_moto_TK_Civ_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class tractor {
		type = "trade_any_vehicle";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
};
