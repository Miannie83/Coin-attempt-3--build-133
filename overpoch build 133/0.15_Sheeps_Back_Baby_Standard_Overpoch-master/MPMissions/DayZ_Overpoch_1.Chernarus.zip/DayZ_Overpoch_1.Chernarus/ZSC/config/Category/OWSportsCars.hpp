class Category_1015 {
class Civcar {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class Civcarbu {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class civcarbl {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class Civcarre {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class Civcarge {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class Civcarwh {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class Civcarsl {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
};