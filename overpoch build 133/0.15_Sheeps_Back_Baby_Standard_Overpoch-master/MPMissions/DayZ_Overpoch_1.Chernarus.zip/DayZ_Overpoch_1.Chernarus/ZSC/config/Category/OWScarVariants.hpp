class Category_1004 {
class SCAR_L_CQC {type = "trade_weapons";buy[] = {60000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_L_CQC_CCO_SD {type = "trade_weapons";buy[] = {65000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_L_CQC_EGLM_Holo {type = "trade_weapons";buy[] = {65000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_L_CQC_Holo {type = "trade_weapons";buy[] = {60000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_L_STD_EGLM_RCO {type = "trade_weapons";buy[] = {65000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_L_STD_HOLO {type = "trade_weapons";buy[] = {60000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_L_STD_Mk4CQT {type = "trade_weapons";buy[] = {60000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_H_CQC_CCO {type = "trade_weapons";buy[] = {60000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_H_CQC_CCO_SD {type = "trade_weapons";buy[] = {65000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_H_LNG_Sniper {type = "trade_weapons";buy[] = {70000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_H_LNG_Sniper_SD {type = "trade_weapons";buy[] = {75000,"Coins"};sell[] = {15000,"Coins"};};
class SCAR_H_STD_EGLM_Spect {type = "trade_weapons";buy[] = {70000,"Coins"};sell[] = {15000,"Coins"};};
};