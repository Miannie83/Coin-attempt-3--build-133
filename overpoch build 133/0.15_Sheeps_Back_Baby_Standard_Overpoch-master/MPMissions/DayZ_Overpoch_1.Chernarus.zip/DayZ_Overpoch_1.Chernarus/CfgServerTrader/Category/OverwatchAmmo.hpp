class Category_1006 {
	class USSR_5Rnd_408 {
	type = "trade_items";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class FHQ_rem_5Rnd_300Win_XM2010_NT {
	type = "trade_items";
	buy[] = {8,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class FHQ_rem_5Rnd_300Win_XM2010_NT_SD {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {4,"ItemGoldBar"};
	};
	class FHQ_rem_7Rnd_338Lapua_MSR_NT {
	type = "trade_items";
	buy[] = {8,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class FHQ_rem_7Rnd_338Lapua_MSR_NT_SD {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {4,"ItemGoldBar"};
	};
	class vil_bhp_mag {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class gms_k98_mag {
	type = "trade_items";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_usp45sd_mag {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class vil_usp45_mag {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar"};
	};
	class vil_10Rnd_762x54_SV {
	type = "trade_items";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {4,"ItemGoldBar"};
	};
	class vil_10Rnd_SVDK {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class vil_20Rnd_762x51_G3 {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class vil_32Rnd_uzi {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class vil_32Rnd_UZI_SD {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_10Rnd_22LR_mk2 {
	type = "trade_items";
	buy[] = {7,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_12Rnd_45cal_usp {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_13Rnd_9x19_bhp {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_15Rnd_9x19_usp {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_15Rnd_9x19_uspsd {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_17Rnd_9x19_g17 {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_17Rnd_9x19_g17SD {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_19Rnd_9x19_g18 {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_20Rnd_32cal_vz61 {
	type = "trade_items";
	buy[] = {7,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class RH_20Rnd_762x51_hk417 {
	type = "trade_items";
	buy[] = {7,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class RH_20Rnd_762x51_SD_hk417 {
	type = "trade_items";
	buy[] = {7,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class RH_20Rnd_9x19_M93 {
	type = "trade_items";
	buy[] = {7,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class RH_30Rnd_9x19_tec {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_32Rnd_9x19_Muzi {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_6Rnd_357_Mag {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_6Rnd_44_Mag {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {1,"ItemGoldBar"};
	};
	class RH_7Rnd_32cal_ppk {
	type = "trade_items";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {4,"ItemGoldBar"};
	};
	class RH_7Rnd_50_AE {
	type = "trade_items";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {4,"ItemGoldBar"};
	};
	class RH_8Rnd_45cal_m1911 {
	type = "trade_items";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {4,"ItemGoldBar"};
	};
	class RH_8Rnd_762_tt33 {
	type = "trade_items";
	buy[] = {5,"ItemGoldBar"};
	sell[] = {1,"ItemGoldBar"};
	};
	class RH_8Rnd_9x19_Mk {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_8Rnd_9x19_Mksd {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class RH_8Rnd_9x19_P38 {
	type = "trade_items";
	buy[] = {6,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
	class FHQ_rem_20Rnd_762x51_PMAG_NT {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class FHQ_rem_20Rnd_762x51_PMAG_NT_SD {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class FHQ_rem_30Rnd_680x43_ACR {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class FHQ_rem_30Rnd_680x43_ACR_SD {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {3,"ItemGoldBar"};
	};
	class 2000Rnd_762x51_M134 {
	type = "trade_items";
	buy[] = {9,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class 200Rnd_556x45_M249 {
	type = "trade_items";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar"};
	};
	class 20rnd_762x51_B_SCAR {
	type = "trade_items";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar"};
	};
	class 20Rnd_762x51_SB_SCAR {
	type = "trade_items";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar"};
	};
	class 20Rnd_9x39_SP5_VSS {
	type = "trade_items";
	buy[] = {8,"ItemGoldBar"};
	sell[] = {2,"ItemGoldBar"};
	};
};
