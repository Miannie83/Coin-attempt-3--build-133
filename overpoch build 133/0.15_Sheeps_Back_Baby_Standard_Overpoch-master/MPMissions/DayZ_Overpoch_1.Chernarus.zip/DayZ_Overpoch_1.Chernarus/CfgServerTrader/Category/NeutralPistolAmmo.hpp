class Category_646 {
	class 15Rnd_9x19_M9 {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 6Rnd_45ACP {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 7Rnd_45ACP_1911 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_9x18_Makarov {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_9x18_MakarovSD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
class Category_611 {
	class 15Rnd_9x19_M9 {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 6Rnd_45ACP {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 7Rnd_45ACP_1911 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_9x18_Makarov {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_9x18_MakarovSD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
