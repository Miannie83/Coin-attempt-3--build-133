class Category_538 {
	class DZ_Patrol_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class CZ_VestPouch_EP1 {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class DZ_ALICE_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
	class DZ_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
	class DZ_Backpack_EP1 {
		type = "trade_backpacks";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class DZ_British_ACU {
		type = "trade_backpacks";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class DZ_CivilBackpack_EP1 {
		type = "trade_backpacks";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class DZ_Czech_Vest_Puch {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class DZ_TK_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class DZ_TerminalPack_EP1 {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class DZ_GunBag_EP1 {
		type = "trade_backpacks";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
};
class Category_688 {
	class DZ_Patrol_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class CZ_VestPouch_EP1 {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class DZ_ALICE_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
	class DZ_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
	class DZ_Backpack_EP1 {
		type = "trade_backpacks";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class DZ_British_ACU {
		type = "trade_backpacks";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class DZ_CivilBackpack_EP1 {
		type = "trade_backpacks";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class DZ_Czech_Vest_Puch {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class DZ_TK_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class DZ_TerminalPack_EP1 {
		type = "trade_backpacks";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class DZ_GunBag_EP1 {
		type = "trade_backpacks";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
};
