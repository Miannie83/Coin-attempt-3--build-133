class Category_1010 {
	class RH_deagle {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_Deagleg {
	type = "trade_weapons";
	buy[] = {6,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class RH_Deaglem {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_Deaglemz {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_Deaglemzb {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_Deagles {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_g17 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar"};
	};
	class RH_g17sd {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class RH_g18 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class RH_g19 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class RH_g19t {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class RH_browninghp {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_bull {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class RH_anac {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class RH_anacg {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_m1911 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class RH_m1911old {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_m1911sd {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_m9 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class RH_m93r {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_m9c {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_m9csd {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_m9sd {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class RH_usp {
	type = "trade_weapons";
	buy[] = {8,"ItemGoldBar"};
	sell[] = {4,"ItemGoldBar"};
	};
	class RH_uspm {
	type = "trade_weapons";
	buy[] = {9,"ItemGoldBar"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_uspsd {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_mk2 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_mk22 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class RH_mk22sd {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class RH_mk22v {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_mk22vsd {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class RH_p226 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class RH_p226s {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class RH_p38 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_ppk {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class RH_python {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class RH_tec9 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class RH_tt33 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class RH_vz61 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class vil_B_HP {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class vil_USP {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_USP45 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class vil_USP45SD {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class vil_USPSD {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class vil_uzi {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class vil_uzimini {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class vil_uzimini_SD {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_uzi_c {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_uzi_SD {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_MP5SD_EOTech {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_MP5_EOTech {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_Glock {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class vil_Glock_o {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
};