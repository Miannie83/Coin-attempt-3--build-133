class Category_602 {
	class G36A_camo {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class G36C {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class G36C_camo {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class G36K_camo {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class M16A2 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class M16A2GL {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class M16A4_ACG {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class M4A1 {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class M4A1_HWS_GL_camo {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class M4A3_CCO_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class M4A1_Aim {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class Sa58P_EP1 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Sa58V_CCO_EP1 {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class Sa58V_EP1 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Sa58V_RCO_EP1 {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class AKS_74_kobra {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class AKS_74_U {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class AK_47_M {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {6,"ItemGoldBar"};
	};
	class AK_74 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class FN_FAL {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class BAF_L85A2_RIS_SUSAT {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class BAF_L85A2_RIS_Holo {
		type = "trade_weapons";
		buy[] = {9,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
};
class Category_637 {
	class G36A_camo {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class G36C {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class G36C_camo {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class G36K_camo {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class M16A2 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class M16A2GL {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class M16A4_ACG {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class M4A1 {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class M4A1_HWS_GL_camo {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class M4A3_CCO_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class M4A1_Aim {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class Sa58P_EP1 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Sa58V_CCO_EP1 {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class Sa58V_EP1 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Sa58V_RCO_EP1 {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class AKS_74_kobra {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class AKS_74_U {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class AK_47_M {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {6,"ItemGoldBar"};
	};
	class AK_74 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class FN_FAL {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class BAF_L85A2_RIS_SUSAT {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class BAF_L85A2_RIS_Holo {
		type = "trade_weapons";
		buy[] = {9,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
};
