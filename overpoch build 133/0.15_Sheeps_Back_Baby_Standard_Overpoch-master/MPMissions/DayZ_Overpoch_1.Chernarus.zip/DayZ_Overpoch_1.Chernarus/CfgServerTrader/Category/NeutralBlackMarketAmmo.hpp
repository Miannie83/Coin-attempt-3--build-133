class Category_527 {
	class 20Rnd_9x39_SP5_VSS {
		type = "trade_items";
		buy[] = {3,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class 8Rnd_B_Beneli_74Slug {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 20Rnd_762x51_SB_SCAR {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
	class 8Rnd_B_Beneli_Pellets {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_B_Saiga12_74Slug {
		type = "trade_items";
		buy[] = {5,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class 8Rnd_B_Saiga12_Pellets {
		type = "trade_items";
		buy[] = {5,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class 20Rnd_B_765x17_Ball {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 10Rnd_762x54_SVD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 5Rnd_762x51_M24 {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 30Rnd_556x45_Stanag {
		type = "trade_items";
		buy[] = {5,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class 100Rnd_556x45_BetaCMag {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class 75Rnd_545x39_RPK {
		type = "trade_items";
		buy[] = {3,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 64Rnd_9x19_Bizon {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 5Rnd_127x108_KSVK {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
