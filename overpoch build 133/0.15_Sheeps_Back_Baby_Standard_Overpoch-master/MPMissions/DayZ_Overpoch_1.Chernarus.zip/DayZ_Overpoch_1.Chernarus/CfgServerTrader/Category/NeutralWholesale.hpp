class Category_675 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] = {3,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {6,"ItemSilverBar10oz"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
};
class Category_636 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] = {3,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {6,"ItemSilverBar10oz"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
};
class Category_555 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {6,"ItemSilverBar10oz"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] = {3,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
		class metal_floor_kit {
		type = "trade_items";
		buy[] = {5,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
		};
};
