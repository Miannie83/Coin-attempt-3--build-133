class Category_479 {
	class ArmoredSUV_PMC_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class Pickup_PK_TK_GUE_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class Offroad_DSHKM_Gue_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Pickup_PK_GUE_DZE {
		type = "trade_any_vehicle";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class Pickup_PK_INS_DZE {
		type = "trade_any_vehicle";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
};
