class Category_487 {
	class SVD_CAMO {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M40A3 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M14_EP1 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class huntingrifle {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class M4SPR {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M24 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
};
class Category_619 {
	class SVD_CAMO {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M40A3 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M14_EP1 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class huntingrifle {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class M4SPR {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M24 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
};
