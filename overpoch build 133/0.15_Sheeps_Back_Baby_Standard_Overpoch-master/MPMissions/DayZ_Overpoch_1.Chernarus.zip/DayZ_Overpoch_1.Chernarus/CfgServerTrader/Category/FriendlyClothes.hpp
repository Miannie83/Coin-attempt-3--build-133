class Category_628 {
	class Skin_Rocker2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorW2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Functionary1_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Haris_Press_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Priest_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWpink_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWurban_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWcombat_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWdesert_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Survivor2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Rocker1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Rocker3_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_RU_Policeman_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Pilot_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Rocker4_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorW3_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
};
class Category_689 {
	class Skin_Rocker2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorW2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Functionary1_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Haris_Press_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Priest_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWpink_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWurban_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWcombat_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorWdesert_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Survivor2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Rocker1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Rocker3_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_RU_Policeman_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Pilot_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Rocker4_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_SurvivorW3_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
};
