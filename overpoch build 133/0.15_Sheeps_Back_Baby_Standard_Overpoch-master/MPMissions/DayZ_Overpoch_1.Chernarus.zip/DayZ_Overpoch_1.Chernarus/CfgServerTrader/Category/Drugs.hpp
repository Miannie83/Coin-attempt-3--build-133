class Category_901 {
	class ItemKiloHemp {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class ItemMorphine {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemPainkiller {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
