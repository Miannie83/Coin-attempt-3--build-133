class Category_665 {
	class ItemAntibiotic {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class ItemBandage {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemBloodbag {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemEpinephrine {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemHeatPack {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMorphine {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemPainkiller {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
class Category_670 {
	class ItemAntibiotic {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class ItemBandage {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemBloodbag {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemEpinephrine {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemHeatPack {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMorphine {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemPainkiller {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
