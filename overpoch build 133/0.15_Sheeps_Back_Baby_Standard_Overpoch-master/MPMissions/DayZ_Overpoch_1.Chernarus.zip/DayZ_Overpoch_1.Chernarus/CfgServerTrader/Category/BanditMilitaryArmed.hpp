class Category_569 {
	class HMMWV_M998A2_SOV_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class HMMWV_M1151_M2_CZ_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {6,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class LandRover_Special_CZ_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class LandRover_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class UAZ_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class GAZ_Vodnik_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
};
