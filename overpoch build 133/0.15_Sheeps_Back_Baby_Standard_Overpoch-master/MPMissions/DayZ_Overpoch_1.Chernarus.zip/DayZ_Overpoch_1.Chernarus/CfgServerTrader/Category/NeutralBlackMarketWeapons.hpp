class Category_526 {
	class Saiga12K {
		type = "trade_weapons";
		buy[] = {5,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class m8_compact {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class m8_sharpshooter {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class m8_holo_sd {
		type = "trade_weapons";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class m8_carbine {
		type = "trade_weapons";
		buy[] = {5,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class M24_des_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class VSS_vintorez {
		type = "trade_weapons";
		buy[] = {3,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar"};
	};
	class SVD_des_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class SVD {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M8_SAW {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class MG36 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class RPK_74 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M60A4_EP1_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class m240_scoped_EP1_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M249_m145_EP1_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class MG36_camo {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class bizon {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class M4A1_HWS_GL_SD_Camo {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class KSVK_DZE {
		type = "trade_weapons";
		buy[] = {3,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
