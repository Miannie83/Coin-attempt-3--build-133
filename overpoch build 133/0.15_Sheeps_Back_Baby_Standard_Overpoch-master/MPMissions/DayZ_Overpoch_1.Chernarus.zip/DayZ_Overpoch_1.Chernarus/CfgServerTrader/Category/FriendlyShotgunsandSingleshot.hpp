class Category_574 {
	class Winchester1866 {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class MR43 {
		type = "trade_weapons";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {8,"ItemSilverBar"};
	};
	class Crossbow_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class M1014 {
		type = "trade_weapons";
		buy[] = {3,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class Remington870_lamp {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class LeeEnfield {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
class Category_620 {
	class Winchester1866 {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class MR43 {
		type = "trade_weapons";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {8,"ItemSilverBar"};
	};
	class Crossbow_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class M1014 {
		type = "trade_weapons";
		buy[] = {3,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class Remington870_lamp {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class LeeEnfield {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
