class Category_519 {
	class Mi17_Civilian_DZ {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class AH6X_DZ {
		type = "trade_any_vehicle";
		buy[] = {6,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class MH6J_DZ {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class CSJ_GyroC {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class CSJ_GyroCover {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class CSJ_GyroP {
		type = "trade_any_vehicle";
		buy[] = {5,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class BAF_Merlin_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
};
