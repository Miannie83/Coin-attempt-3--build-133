class Category_534 {
	class Pickup_PK_GUE_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class Pickup_PK_INS_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class ArmoredSUV_PMC_DZE {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class Pickup_PK_TK_GUE_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {4,"ItemGoldBar"};
	};
	class Offroad_DSHKM_Gue_DZE {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
