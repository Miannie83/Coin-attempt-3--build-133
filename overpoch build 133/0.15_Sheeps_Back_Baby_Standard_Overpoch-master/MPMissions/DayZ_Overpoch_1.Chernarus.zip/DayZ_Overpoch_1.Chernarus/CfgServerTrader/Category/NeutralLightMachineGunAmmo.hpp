class Category_644 {
	class 100Rnd_762x51_M240 {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class 200Rnd_556x45_M249 {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class 100Rnd_762x54_PK {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
};
class Category_610 {
	class 100Rnd_762x51_M240 {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class 200Rnd_556x45_M249 {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class 100Rnd_762x54_PK {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
};
