class Category_564 {
	class Ural_CDF {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Ural_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Ural_UN_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_Open_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_Open_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Kamaz {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class MTVR_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_Civ {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_RA_TK_GUE_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class UralCivil_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class UralCivil2_DZE {
		type = "trade_any_vehicle";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class KamazOpen_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class MTVR {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
class Category_570 {
	class Ural_CDF {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Ural_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Ural_UN_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_Open_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_Open_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Kamaz {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class MTVR_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_Civ {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_RA_TK_GUE_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class V3S_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class UralCivil_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class UralCivil2_DZE {
		type = "trade_any_vehicle";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class KamazOpen_DZE {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class MTVR {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
