class Category_1013 {
class Civcar {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class Civcarbu {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class civcarbl {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class Civcarre {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class Civcarge {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class Civcarwh {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class Civcarsl {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_red {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_kiwi {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_black {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_silver {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_green {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_blue {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_gold {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_white {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_pink {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_mod {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_ruben {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_v {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_city {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
class 350z_yellow {
type = "trade_any_vehicle";
buy[] = {3,"ItemGoldBar10oz"};
sell[] = {1,"ItemGoldBar10oz"};
};
};