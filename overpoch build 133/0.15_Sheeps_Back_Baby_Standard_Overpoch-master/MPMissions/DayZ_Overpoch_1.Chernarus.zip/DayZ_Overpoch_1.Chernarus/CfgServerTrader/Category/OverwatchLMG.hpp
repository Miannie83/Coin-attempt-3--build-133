class Category_1008 {
	class vil_M240_B {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_M249_Para {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class vil_FnMag {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class vil_Mg3 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_MG4 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_MG4E {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class vil_Minimi {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class vil_MPi {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_PK {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_PKM {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_PKP {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_PKP_EOT {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_PMI {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_PMI74S {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_PMIS {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPK {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPK74 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPK74M {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPK74M_P29 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPK75 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPK75_M72 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_RPK75_Romania {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_zastava_m84 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class skavil_M60 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class skavil_M60e3 {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
};
