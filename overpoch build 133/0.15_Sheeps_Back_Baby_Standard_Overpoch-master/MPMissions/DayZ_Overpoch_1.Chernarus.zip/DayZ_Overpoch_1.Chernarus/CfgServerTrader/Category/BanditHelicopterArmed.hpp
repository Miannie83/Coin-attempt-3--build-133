class Category_512 {
	class CH_47F_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {6,"ItemBriefcase100oz"};
		sell[] = {2,"ItemBriefcase100oz"};
	};
	class UH1H_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class Mi17_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class UH60M_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class UH1Y_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class MH60S_DZE {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class CH53_DZE {
		type = "trade_any_vehicle";
		buy[] = {6,"ItemBriefcase100oz"};
		sell[] = {2,"ItemBriefcase100oz"};
	};
};
