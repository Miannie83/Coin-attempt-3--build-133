class Category_650 {
	class MMT_Civ {
		type = "trade_any_bicycle";
		buy[] = {4,"ItemSilverBar"};
		sell[] = {2,"ItemSilverBar"};
	};
	class Old_bike_TK_INS_EP1 {
		type = "trade_any_bicycle";
		buy[] = {4,"ItemSilverBar"};
		sell[] = {2,"ItemSilverBar"};
	};
	class TT650_Civ {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class TT650_Ins {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class TT650_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ATV_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ATV_US_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class M1030_US_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Old_moto_TK_Civ_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class tractor {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
class Category_587 {
	class MMT_Civ {
		type = "trade_any_bicycle";
		buy[] = {4,"ItemSilverBar"};
		sell[] = {2,"ItemSilverBar"};
	};
	class Old_bike_TK_INS_EP1 {
		type = "trade_any_bicycle";
		buy[] = {4,"ItemSilverBar"};
		sell[] = {2,"ItemSilverBar"};
	};
	class TT650_Civ {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class TT650_Ins {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class TT650_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ATV_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ATV_US_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class M1030_US_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Old_moto_TK_Civ_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class tractor {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
