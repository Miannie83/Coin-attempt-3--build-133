class Category_647 {
	class 20Rnd_762x51_DMR {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 10Rnd_762x54_SVD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 5Rnd_762x51_M24 {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 5x_22_LR_17_HMR {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
};
class Category_614 {
	class 20Rnd_762x51_DMR {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 10Rnd_762x54_SVD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 5Rnd_762x51_M24 {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class 5x_22_LR_17_HMR {
		type = "trade_items";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
};
