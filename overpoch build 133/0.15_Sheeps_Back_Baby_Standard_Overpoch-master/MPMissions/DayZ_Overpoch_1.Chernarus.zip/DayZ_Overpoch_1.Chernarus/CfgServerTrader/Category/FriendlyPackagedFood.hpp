class Category_629 {
	class FoodCanBakedBeans {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodCanFrankBeans {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodCanPasta {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodCanSardines {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodMRE {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class FoodPistachio {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodNutmix {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
class Category_692 {
	class FoodCanBakedBeans {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodCanFrankBeans {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodCanPasta {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodCanSardines {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodMRE {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class FoodPistachio {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class FoodNutmix {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
