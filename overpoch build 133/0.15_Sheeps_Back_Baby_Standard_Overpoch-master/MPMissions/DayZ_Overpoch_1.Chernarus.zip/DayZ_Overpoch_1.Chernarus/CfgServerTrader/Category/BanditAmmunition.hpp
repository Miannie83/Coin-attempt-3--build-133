class Category_577 {
	class 30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class 5Rnd_86x70_L115A1 {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class 100Rnd_762x51_M240 {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class 20Rnd_762x51_SB_SCAR {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
};
