class Category_678 {
	class ItemSandbag {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class ItemTankTrap {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class ItemTentOld {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class ItemVault {
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class ItemWire {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class 30m_plot_kit {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar10oz"};
	};
	class ItemCorrugated {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemPole {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemTentDomed {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class ItemTentDomed2 {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class ItemLightBulb {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class ItemGenerator {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemComboLock{
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemMixOil{
		type = "trade_items";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class ChainSaw{
		type = "trade_weapons";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawB{
		type = "trade_weapons";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawG{
		type = "trade_weapons";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawp{
		type = "trade_weapons";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawR{
		type = "trade_weapons";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
};
class Category_680 {
	class ItemSandbag {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class ItemTankTrap {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class ItemTentOld {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class ItemVault {
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class ItemWire {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class 30m_plot_kit {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar10oz"};
	};
	class ItemCorrugated {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemPole {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemTentDomed {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class ItemTentDomed2 {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class ItemLightBulb {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class ItemGenerator {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemComboLock{
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemMixOil{
		type = "trade_items";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class ChainSaw{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawB{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawG{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawp{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawR{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
};
class Category_530 {
	class ItemSandbag {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class ItemTankTrap {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class ItemTentOld {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class ItemVault {
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {1,"ItemBriefcase100oz"};
	};
	class ItemWire {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class 30m_plot_kit {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar10oz"};
	};
	class ItemCorrugated {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemPole {
		type = "trade_items";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemTentDomed {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class ItemTentDomed2 {
		type = "trade_items";
		buy[] = {6,"ItemSilverBar10oz"};
		sell[] = {3,"ItemSilverBar10oz"};
	};
	class ItemLightBulb {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class ItemGenerator {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemComboLock{
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemMixOil{
		type = "trade_items";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class ChainSaw{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawB{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawG{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawp{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class ChainSawR{
		type = "trade_items";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
};
