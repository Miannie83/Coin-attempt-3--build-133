class Category_621 {
	class 30Rnd_556x45_Stanag {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar"};
		sell[] = {2,"ItemSilverBar"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class 30Rnd_545x39_AK {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 30Rnd_762x39_AK47 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 30Rnd_762x39_SA58 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
class Category_480 {
	class 30Rnd_556x45_Stanag {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar"};
		sell[] = {2,"ItemSilverBar"};
	};
	class 20Rnd_762x51_FNFAL {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class 30Rnd_545x39_AK {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 30Rnd_762x39_AK47 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 30Rnd_762x39_SA58 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
