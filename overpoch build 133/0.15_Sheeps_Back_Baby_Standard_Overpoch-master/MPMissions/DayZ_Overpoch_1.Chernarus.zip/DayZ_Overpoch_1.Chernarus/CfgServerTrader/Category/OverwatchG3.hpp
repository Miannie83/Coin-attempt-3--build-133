class Category_1007 {
	class vil_AG3 {
	type = "trade_weapons";
	buy[] = {8,"ItemGoldBar"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_AG36 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class vil_AG36A2 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {8,"ItemGoldBar"};
	};
	class vil_AG36KA4 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class vil_AG36KV {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AG3EOT {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_Vikhr {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36a2 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {4,"ItemGoldBar"};
	};
	class vil_G36CC {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_G36E {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class vil_G36KA4 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36KES {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36KSK {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36KSKdes {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class vil_G36KSKdesES {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36KSKES {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36KV3 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36KV3Des {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36KVA4 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class vil_G36KVZ {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar"};
	};
	class vil_G36VA4 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G36VA4Eot {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_G3a2 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {4,"ItemGoldBar"};
	};
	class vil_G3a3 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {4,"ItemGoldBar"};
	};
	class vil_G3a4 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_G3a4b {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class vil_G3an {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_G3anb {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {6,"ItemGoldBar"};
	};
	class vil_G3TGS {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class vil_G3TGSb {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_G3ZF {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class vil_G3zfb {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {9,"ItemGoldBar"};
	};
	class vil_Galil {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_Galil_arm {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
};