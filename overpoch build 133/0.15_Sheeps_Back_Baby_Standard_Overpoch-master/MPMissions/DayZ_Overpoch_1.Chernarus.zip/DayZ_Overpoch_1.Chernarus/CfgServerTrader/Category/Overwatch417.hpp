class Category_1002 {
	class RH_hk417 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class RH_hk417acog {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_hk417aim {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_hk417eotech {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_hk417s {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_hk417sacog {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_hk417saim {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_hk417sd {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_hk417sdacog {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_hk417sdaim {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class RH_hk417sdeotech {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_hk417sdsp {
	type = "trade_weapons";
	buy[] = {9,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_hk417seotech {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_hk417sgl {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_hk417sglacog {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_hk417sglaim {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
};
