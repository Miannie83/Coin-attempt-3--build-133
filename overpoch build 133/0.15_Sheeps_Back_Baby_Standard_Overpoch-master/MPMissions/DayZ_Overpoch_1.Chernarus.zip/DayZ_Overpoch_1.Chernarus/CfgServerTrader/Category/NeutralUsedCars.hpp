class Category_660 {
	class Skoda {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class SkodaBlue {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class SkodaGreen {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class SkodaRed {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class VolhaLimo_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Volha_1_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Volha_2_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class VWGolf {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class car_hatchback {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class car_sedan {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class GLT_M300_LT {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class GLT_M300_ST {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada1_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada2 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada2_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class LadaLM {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
};
class Category_520 {
	class Skoda {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class SkodaBlue {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class SkodaGreen {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class SkodaRed {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class VolhaLimo_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Volha_1_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Volha_2_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class VWGolf {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class car_hatchback {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class car_sedan {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class GLT_M300_LT {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class GLT_M300_ST {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada1_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada2 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Lada2_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class LadaLM {
		type = "trade_any_vehicle";
		buy[] = {3,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
};
