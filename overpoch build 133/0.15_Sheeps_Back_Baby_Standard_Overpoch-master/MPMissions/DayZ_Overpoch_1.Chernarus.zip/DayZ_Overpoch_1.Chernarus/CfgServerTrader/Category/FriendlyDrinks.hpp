class Category_601 {
	class ItemSodaCoke {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemSodaPepsi {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemSodaMdew {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemSodaR4z0r {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemWaterbottleUnfilled {
		type = "trade_items";
		buy[] = {3,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemSodaRbull {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemSodaOrangeSherbet {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
};
class Category_691 {
	class ItemSodaCoke {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemSodaPepsi {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemSodaMdew {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemSodaR4z0r {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemWaterbottleUnfilled {
		type = "trade_items";
		buy[] = {3,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemSodaRbull {
		type = "trade_items";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class ItemSodaOrangeSherbet {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
};
