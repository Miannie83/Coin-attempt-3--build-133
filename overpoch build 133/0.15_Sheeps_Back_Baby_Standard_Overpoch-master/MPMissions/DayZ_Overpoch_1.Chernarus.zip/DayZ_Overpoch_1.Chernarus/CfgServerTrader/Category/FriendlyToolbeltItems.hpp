class Category_679 {
	class ItemCompass {
		type = "trade_weapons";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class Binocular {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class Binocular_Vector {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemEtool {
		type = "trade_weapons";
		buy[] = {9,"ItemSilverBar10oz"};
		sell[] = {6,"ItemSilverBar10oz"};
	};
	class ItemFlashlight {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemFlashlightRed {
		type = "trade_weapons";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemGPS {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemHatchet_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemKnife {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMap {
		type = "trade_weapons";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class ItemMatchbox_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemToolbox {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemWatch {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class NVGoggles {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemCrowbar {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMachete {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemFishingPole {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
class Category_681 {
	class ItemCompass {
		type = "trade_weapons";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class Binocular {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class Binocular_Vector {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemEtool {
		type = "trade_weapons";
		buy[] = {9,"ItemSilverBar10oz"};
		sell[] = {6,"ItemSilverBar10oz"};
	};
	class ItemFlashlight {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemFlashlightRed {
		type = "trade_weapons";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemGPS {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemHatchet_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemKnife {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMap {
		type = "trade_weapons";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class ItemMatchbox_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemToolbox {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemWatch {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class NVGoggles {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemCrowbar {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMachete {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemFishingPole {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
class Category_532 {
	class ItemCompass {
		type = "trade_weapons";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class Binocular {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class Binocular_Vector {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemEtool {
		type = "trade_weapons";
		buy[] = {9,"ItemSilverBar10oz"};
		sell[] = {6,"ItemSilverBar10oz"};
	};
	class ItemFlashlight {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemFlashlightRed {
		type = "trade_weapons";
		buy[] = {1,"ItemSilverBar10oz"};
		sell[] = {5,"ItemSilverBar"};
	};
	class ItemGPS {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemHatchet_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemKnife {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMap {
		type = "trade_weapons";
		buy[] = {6,"ItemSilverBar"};
		sell[] = {3,"ItemSilverBar"};
	};
	class ItemMatchbox_DZE {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemToolbox {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemWatch {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class NVGoggles {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class ItemCrowbar {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemMachete {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class ItemFishingPole {
		type = "trade_weapons";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
