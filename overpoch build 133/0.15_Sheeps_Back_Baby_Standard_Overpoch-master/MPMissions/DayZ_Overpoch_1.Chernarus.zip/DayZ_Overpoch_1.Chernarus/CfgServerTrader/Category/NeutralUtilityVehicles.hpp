class Category_661 {
	class SUV_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Blue {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Charcoal {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Green {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Orange {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Pink {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Red {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Silver {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_White {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Yellow {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Camo {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class UAZ_CDF {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_INS {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_RU {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_Unarmed_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_Unarmed_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_Unarmed_UN_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
};
class Category_591 {
	class SUV_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Blue {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Charcoal {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Green {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Orange {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Pink {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Red {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Silver {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_White {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Yellow {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class SUV_Camo {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class UAZ_CDF {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_INS {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_RU {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_Unarmed_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_Unarmed_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class UAZ_Unarmed_UN_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
};
