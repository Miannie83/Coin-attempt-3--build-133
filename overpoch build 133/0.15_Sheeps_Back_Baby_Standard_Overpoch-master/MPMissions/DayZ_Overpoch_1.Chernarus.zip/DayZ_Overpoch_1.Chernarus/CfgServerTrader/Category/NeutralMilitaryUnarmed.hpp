class Category_658 {
	class HMMWV_M1035_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class HMMWV_Ambulance {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class HMMWV_Ambulance_CZ_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class HMMWV_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class GAZ_Vodnik_MedEvac {
		type = "trade_any_vehicle";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class HMMWV_DZ {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class LandRover_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class LandRover_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
class Category_598 {
	class HMMWV_M1035_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class HMMWV_Ambulance {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class HMMWV_Ambulance_CZ_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class HMMWV_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class GAZ_Vodnik_MedEvac {
		type = "trade_any_vehicle";
		buy[] = {1,"ItemBriefcase100oz"};
		sell[] = {5,"ItemGoldBar10oz"};
	};
	class HMMWV_DZ {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class LandRover_CZ_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class LandRover_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
