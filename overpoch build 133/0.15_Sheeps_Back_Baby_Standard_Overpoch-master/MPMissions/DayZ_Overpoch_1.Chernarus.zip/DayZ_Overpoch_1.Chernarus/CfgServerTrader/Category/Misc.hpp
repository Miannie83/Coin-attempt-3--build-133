class Category_902 {
	class ItemRadio {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
