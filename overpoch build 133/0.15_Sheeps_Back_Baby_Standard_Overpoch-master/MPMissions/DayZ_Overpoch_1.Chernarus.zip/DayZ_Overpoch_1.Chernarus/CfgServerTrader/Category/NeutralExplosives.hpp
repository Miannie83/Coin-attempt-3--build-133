class Category_529 {
	class HandGrenade_west {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class PipeBomb {
		type = "trade_items";
		buy[] = {4,"ItemBriefcase100oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class 1Rnd_HE_M203 {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class HandGrenade_east {
		type = "trade_items";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
};
