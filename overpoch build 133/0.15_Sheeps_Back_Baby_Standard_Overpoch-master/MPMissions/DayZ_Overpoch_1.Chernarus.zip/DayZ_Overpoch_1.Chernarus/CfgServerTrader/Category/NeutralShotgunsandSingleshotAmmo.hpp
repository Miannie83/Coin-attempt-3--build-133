class Category_649 {
	class 15Rnd_W1866_Slug {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 2Rnd_shotgun_74Pellets {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 2Rnd_shotgun_74Slug {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_B_Beneli_74Slug {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_B_Beneli_Pellets {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class WoodenArrow {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class Quiver {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 10x_303 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
class Category_613 {
	class 15Rnd_W1866_Slug {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 2Rnd_shotgun_74Pellets {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 2Rnd_shotgun_74Slug {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_B_Beneli_74Slug {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 8Rnd_B_Beneli_Pellets {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class WoodenArrow {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class Quiver {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
	class 10x_303 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar"};
		sell[] = {1,"ItemSilverBar"};
	};
};
