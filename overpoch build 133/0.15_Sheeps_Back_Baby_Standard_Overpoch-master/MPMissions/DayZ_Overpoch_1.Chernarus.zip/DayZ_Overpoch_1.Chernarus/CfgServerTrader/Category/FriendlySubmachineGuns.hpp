class Category_488 {
	class bizon_silenced {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class UZI_EP1 {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class Sa61_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
	class MP5A5 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class UZI_SD_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class MP5SD {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
};
class Category_618 {
	class bizon_silenced {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class UZI_EP1 {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar"};
		sell[] = {2,"ItemGoldBar"};
	};
	class Sa61_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {5,"ItemSilverBar10oz"};
	};
	class MP5A5 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class UZI_SD_EP1 {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class MP5SD {
		type = "trade_weapons";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
};
