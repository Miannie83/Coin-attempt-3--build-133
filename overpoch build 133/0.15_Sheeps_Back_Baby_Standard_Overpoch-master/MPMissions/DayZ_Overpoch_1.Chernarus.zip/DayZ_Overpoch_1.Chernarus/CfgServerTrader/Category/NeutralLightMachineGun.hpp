class Category_603 {
	class M249_EP1_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Pecheneg_DZ {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
			class M249_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
};
class Category_638 {
	class M249_EP1_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Pecheneg_DZ {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
		class M249_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {6,"ItemGoldBar"};
	};
};
