class Category_517 {
	class AN2_DZ {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class C130J_US_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemBriefcase100oz"};
		sell[] = {2,"ItemBriefcase100oz"};
	};
	class MV22_DZ {
		type = "trade_any_vehicle";
		buy[] = {5,"ItemBriefcase100oz"};
		sell[] = {2,"ItemBriefcase100oz"};
	};
	class GNT_C185U {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class GNT_C185 {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class GNT_C185R {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class GNT_C185C {
		type = "trade_any_vehicle";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
};
