class Category_673 {
	class RHIB {
		type = "trade_any_boat";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
};
class Category_558 {
	class RHIB {
		type = "trade_any_boat";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
};
