class Category_575 {
	class Skin_Bandit1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Bandit2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_GUE_Commander_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_GUE_Soldier_2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_GUE_Soldier_CO_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_GUE_Soldier_Crew_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_GUE_Soldier_Sniper_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_Ins_Soldier_GL_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_TK_INS_Soldier_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_TK_INS_Warlord_EP1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_BanditW1_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
	class Skin_BanditW2_DZ {
		type = "trade_items";
		buy[] = {2,"ItemGoldBar"};
		sell[] = {1,"ItemGoldBar"};
	};
};
