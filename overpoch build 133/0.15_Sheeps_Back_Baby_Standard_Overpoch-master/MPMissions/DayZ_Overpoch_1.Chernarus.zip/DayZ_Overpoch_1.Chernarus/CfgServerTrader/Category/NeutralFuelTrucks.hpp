class Category_655 {
	class KamazRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class MtvrRefuel_DES_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class UralRefuel_TK_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class V3S_Refuel_TK_GUE_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class MtvrRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
};
class Category_589 {
	class KamazRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class MtvrRefuel_DES_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class UralRefuel_TK_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class V3S_Refuel_TK_GUE_EP1_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
	class MtvrRefuel_DZ {
		type = "trade_any_vehicle";
		buy[] = {7,"ItemGoldBar10oz"};
		sell[] = {3,"ItemGoldBar10oz"};
	};
};
