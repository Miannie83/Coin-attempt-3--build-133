class Category_909 {
	class ItemOilBarrel  {
		type = "trade_items";
		buy[] = {5,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
};
