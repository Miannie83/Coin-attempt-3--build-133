class Category_659 {
	class hilux1_civil_3_open_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class datsun1_civil_3_open {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class hilux1_civil_1_open {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class datsun1_civil_2_covered {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class datsun1_civil_1_open {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class hilux1_civil_2_covered {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
};
class Category_590 {
	class hilux1_civil_3_open_EP1 {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class datsun1_civil_3_open {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class hilux1_civil_1_open {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class datsun1_civil_2_covered {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class datsun1_civil_1_open {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
	class hilux1_civil_2_covered {
		type = "trade_any_vehicle";
		buy[] = {8,"ItemGoldBar"};
		sell[] = {4,"ItemGoldBar"};
	};
};
