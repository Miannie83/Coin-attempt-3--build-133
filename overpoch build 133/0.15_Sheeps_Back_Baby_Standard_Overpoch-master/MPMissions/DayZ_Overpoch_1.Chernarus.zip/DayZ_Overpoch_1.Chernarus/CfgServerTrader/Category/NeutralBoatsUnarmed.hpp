class Category_672 {
	class Smallboat_1 {
		type = "trade_any_boat";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Smallboat_2 {
		type = "trade_any_boat";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Zodiac {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class Fishing_Boat {
		type = "trade_any_boat";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class PBX {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Red {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Yellow {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Green {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Blue {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
};
class Category_557 {
	class Smallboat_1 {
		type = "trade_any_boat";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Smallboat_2 {
		type = "trade_any_boat";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class Zodiac {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class Fishing_Boat {
		type = "trade_any_boat";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class PBX {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Red {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Yellow {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Green {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
	class JetSkiYanahui_Case_Blue {
		type = "trade_any_boat";
		buy[] = {6,"ItemGoldBar"};
		sell[] = {3,"ItemGoldBar"};
	};
};
