class Category_1003 {
	class vil_ak12 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_ak12_ap {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_ak12_gp {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AKM {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_AKMS {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AKMSB {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AKMS_GP25 {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AKM_GL {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AKS_47 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AKS_74 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AKS_74p {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AKS_74p_45 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AKS_74p_gp {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AKS_74_gp {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AKs_74_u {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AKs_74_u45 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class Vil_AKS_74_UB {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class Vil_AKS_74_UN_kobra {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_AK_101 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_103 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_105 {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class Vil_AK_105_c {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class vil_AK_107 {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class Vil_AK_107_c {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class vil_AK_47 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {5,"ItemGoldBar"};
	};
	class vil_AK_47_49 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_47_m1 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AK_74 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74m {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_c {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_EOT {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_EOT_Alfa {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_EOT_FSB {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_EOT_FSB_45 {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_EOT_FSB_60 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_gp {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_gp_29 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_k {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74m_p29 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74M_PSO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74P {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74_gp {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_74_N {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AK_nato_m1 {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AK_nato_m80 {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AEK1 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AEK2 {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AeK_23 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AeK_3 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AeK_3_K {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AEK_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_AMD {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_AMD63 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_ASH82 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_M64 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_M70 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_M70B {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_type88_1 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_9a91 {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_9a91_c {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_9a91_csd {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_Abakan {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_Abakan_gp {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_Abakan_P29 {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class vil_VAL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class vil_VAL_C {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
};