class Category_626 {
	class 30rnd_9x19_MP5 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class 30Rnd_9x19_UZI {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 64Rnd_9x19_SD_Bizon {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 30Rnd_9x19_UZI_SD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 20Rnd_B_765x17_Ball {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
class Category_483 {
	class 30rnd_9x19_MP5 {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] = {4,"ItemSilverBar10oz"};
		sell[] = {2,"ItemSilverBar10oz"};
	};
	class 30Rnd_9x19_UZI {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 64Rnd_9x19_SD_Bizon {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 30Rnd_9x19_UZI_SD {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
	class 20Rnd_B_765x17_Ball {
		type = "trade_items";
		buy[] = {2,"ItemSilverBar10oz"};
		sell[] = {1,"ItemSilverBar10oz"};
	};
};
