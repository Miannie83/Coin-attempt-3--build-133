class Category_1005 {
	class FHQ_ACR_SNW_CCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_CCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_CCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_CCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_CCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_CCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_CCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_CCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_G33_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HAMR_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_HWS_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_IRN_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_SNW_RCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_CCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_G33_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HAMR_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_HWS_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_IRN_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_BLK_RCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_CCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_G33_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HAMR_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_HWS_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_IRN_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_TAN_RCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_CCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33 {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_G33_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HAMR_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_HWS_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_IRN_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO_GL {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO_GL_F {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO_GL_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO_GL_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO_SD {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class FHQ_ACR_WDL_RCO_SD_F {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
};
