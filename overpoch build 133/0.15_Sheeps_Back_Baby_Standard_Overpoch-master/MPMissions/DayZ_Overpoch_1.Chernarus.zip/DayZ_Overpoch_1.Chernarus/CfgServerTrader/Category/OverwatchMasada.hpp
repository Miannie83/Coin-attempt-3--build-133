class Category_1009 {
	class RH_mas {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class RH_masacog {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_masaim {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_masb {
	type = "trade_weapons";
	buy[] = {1,"ItemGoldBar10oz"};
	sell[] = {7,"ItemGoldBar"};
	};
	class RH_masbacog {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_masbaim {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_masbeotech {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_masbsd {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_masbsdacog {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_masbsdaim {
	type = "trade_weapons";
	buy[] = {5,"ItemGoldBar10oz"};
	sell[] = {3,"ItemGoldBar10oz"};
	};
	class RH_masbsdeotech {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_maseotech {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_massd {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_massdacog {
	type = "trade_weapons";
	buy[] = {2,"ItemGoldBar10oz"};
	sell[] = {1,"ItemGoldBar10oz"};
	};
	class RH_massdaim {
	type = "trade_weapons";
	buy[] = {4,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
	class RH_massdeotech {
	type = "trade_weapons";
	buy[] = {3,"ItemGoldBar10oz"};
	sell[] = {2,"ItemGoldBar10oz"};
	};
};