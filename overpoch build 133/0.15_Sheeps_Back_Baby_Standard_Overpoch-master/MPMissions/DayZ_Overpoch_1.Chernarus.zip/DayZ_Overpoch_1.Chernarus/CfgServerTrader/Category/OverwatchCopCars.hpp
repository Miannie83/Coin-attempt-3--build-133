class Category_1012 {
	class CVPI_Patrol {
	type = "trade_any_vehicle";
	buy[] = {1,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_Trooper_Patrol {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_TrooperSL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_NYPD_Patrol {
	type = "trade_any_vehicle";
	buy[] = {1,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_HighwaySL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_UnmarkedB_Patrol {
	type = "trade_any_vehicle";
	buy[] = {1,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_UnmarkedG_Patrol {
	type = "trade_any_vehicle";
	buy[] = {1,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_LAPD_Patrol {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_UnmarkedW_Patrol {
	type = "trade_any_vehicle";
	buy[] = {1,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_LAPDSL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class CVPI_NYPDSL_Patrol {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class policecar {
	type = "trade_any_vehicle";
	buy[] = {1,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class Copcar {
	type = "trade_any_vehicle";
	buy[] = {1,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class Copcarhw {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
	class Copcarswat {
	type = "trade_any_vehicle";
	buy[] = {2,"ItemBriefcase100oz"};
	sell[] = {8,"ItemGoldBar10oz"};
	};
};