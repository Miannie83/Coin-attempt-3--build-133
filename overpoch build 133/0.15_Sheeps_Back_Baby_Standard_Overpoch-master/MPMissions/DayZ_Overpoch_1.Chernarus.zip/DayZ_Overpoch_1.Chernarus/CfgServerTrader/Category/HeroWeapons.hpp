class Category_477 {
	class G36_C_SD_camo {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class M4A1_AIM_SD_camo {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class FN_FAL_ANPVS4 {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class SCAR_H_LNG_Sniper_SD {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class BAF_LRR_scoped {
		type = "trade_weapons";
		buy[] = {4,"ItemGoldBar10oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class FN_FAL {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class Mk_48_DZ {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class M240_DZ {
		type = "trade_weapons";
		buy[] = {1,"ItemGoldBar10oz"};
		sell[] = {5,"ItemGoldBar"};
	};
	class DMR {
		type = "trade_weapons";
		buy[] = {2,"ItemGoldBar10oz"};
		sell[] = {1,"ItemGoldBar10oz"};
	};
	class M107_DZ {
		type = "trade_weapons";
		buy[] = {2,"ItemBriefcase100oz"};
		sell[] = {2,"ItemGoldBar10oz"};
	};
	class  M110_NVG_EP1 {
		type = "trade_weapons";
		buy[] = {2,"ItemBriefcase100oz"};
		sell[] = {9,"ItemGoldBar10oz"};
	};
};
