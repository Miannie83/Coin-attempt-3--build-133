class Category_900 {
	class ItemRuby {
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemEmerald {
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemTopaz {
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemObsidian {
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemSapphire {
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemAmethyst {
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
	class ItemCitrine {
		type = "trade_items";
		buy[] = {8,"ItemGoldBar10oz"};
		sell[] = {4,"ItemGoldBar10oz"};
	};
};
